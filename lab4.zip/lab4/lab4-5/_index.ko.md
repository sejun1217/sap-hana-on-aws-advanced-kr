---
title: Task 05 - Upgrade Cluster Software(Optional)
weight: 30
pre: "<b> </b>"

---
{{% notice warning %}}
***이번 실습은 실습 시점의 업데이트 상황에 따라 업데이트가 적용되지 않거나 현재 구성된 HA Cluster의 상태 변경으로 예상하지 못한 테스트 시나리오에 영향이 발생할 가능성이 있습니다. 예상치 못한 영향에 대한 문제 해결이 필요할 경우, 이는 이번 워크샵의 실습 범위를 벗어나게 되며 이후 진행하게 될 Lab 06. Cost Optimized Conifguration 실습과정 진행에도 영향을 주게 됩니다. 모든 실습이 종료된 이후 마지막으로 수행해 보는 것을 권장드립니다.***
{{% /notice %}}

{{% notice note %}}
이 실습에서는 두 개의 클러스터 노드 모두에서 SUSE Linux를 업데이트하는 방법을 보여 줍니다.
{{% /notice %}}

### 노드에 패키지 업데이트를 설치하기 전 반드시 다음 사항들을 확인하십시오.

업데이트가 SUSE Linux Enterprise High Availability Extension or Geo Clustering for SUSE Linux Enterprise High Availability Extension에 속하는 패키지에 영향을 주는가?

1. 패키지 업데이트에 재부팅이 필요한 경우에는 소프트웨어 업데이트를 시작하기 전에 보조 노드에서 클러스터 스택을 중지합니다.
    ```shell
    sudo su -
    crm cluster stop
    ```

2. 패키지 업데이트 설치 :
    ```shell
    sudo su -
    zypper up
    ```

3. 사용 가능한 패치 표시 :
    ```shell
    sudo su -
    zypper lp
    ```

4. 사용 가능한 업데이트 표시 :
    ```shell
    sudo su -
    zypper lu
    ```

5. 각 노드에서 클러스터 스택을 시작하거나 서버를 재시작하십시오.
    ```shell
    sudo su -
    crm cluster start

    or

    sudo su -
    reboot
    ```
6. Lab 02. Task 03. HAWK(High Availability Web Konsole)을 수행하여 Web을 통해 Cluster의 상태를 확인합니다.

7. Lab 03. Task 01. Validation of Cluster를 수행하여 CLI를 통해 Cluster의 상태를 확인합니다.

---

위의 상황이 적용되지 않는 경우 클러스터 스택을 중지 할 필요가 없습니다.
1. 이 경우에는 소프트웨어 업데이트를 시작하기 전에 노드를 유지 관리 모드로 전환하십시오. 여기서 `<NODE_NAME>`은 클러스터 노드의 이름입니다.  
crm node maintenance `<NODE_NAME>`

2. 패키지 업데이트 설치 :
    ```shell
    sudo su -
    zypper up
    ```

3. 사용 가능한 패치 표시 :
    ```shell
    sudo su -
    zypper lp
    ```

4. 사용 가능한 업데이트 표시 :
    ```shell
    sudo su -
    zypper lu
    ```

5. 작업 완료 후 유지 보수 플래그를 제거하여 노드를 정상 모드로 되돌립니다.
여기서 `<NODE_NAME>`은 클러스터 노드의 이름입니다.
    ```shell
    sudo su -
    crm node ready `<NODE_NAME>`
    ```

6. Lab 02. Task 03. HAWK(High Availability Web Konsole)을 수행하여 Web을 통해 Cluster의 상태를 확인합니다.

7. Lab 03. Task 01. Validation of Cluster를 수행하여 CLI를 통해 Cluster의 상태를 확인합니다.

---

## Performing a Cluster-wide Rolling Upgrade from one service pack to the next
{{% notice note %}}
특정 서비스 팩에서 다음 서비스 팩으로 클러스터 전체의 롤링 업그레이드 수행하는 경우 전체 서비스 팩 업그레이드를 수행하려면 업데이트를 위해 하나의 노드를 오프라인으로 전환하여 업그레이드를 진행한 다음 다시 TakeBack하여 다른 노드에서 업그레이드를 진행하는 절차를 반복해야 합니다.
{{% /notice %}}

1. 업그레이드하려는 노드에 루트로 로그인하고 클러스터 스택을 중지합니다.
crm cluster stop
2. SAP 애플리케이션 용 SUSE Linux Enterprise Server의 원하는 대상 버전으로 업그레이드를 수행합니다.
3. 업그레이드가 완료된 노드에서 클러스터 스택을 시작하여 노드가 클러스터에 다시 참여하도록합니다.
crm cluster start
4. 다음 노드로 이동하기 전에 "crm_mon -rfn1"또는 Hawk2로 클러스터 상태를 확인합니다.
5. 다음 노드를 오프라인으로 전환하고 해당 노드에 대해 절차를 반복합니다.

---
<p align="center">
© 2019 Amazon Web Services, Inc. 또는 자회사, All rights reserved.
</p>
