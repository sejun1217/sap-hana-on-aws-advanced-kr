---
title: Task 01. Migrate Cluster
weight: 30
pre: "<b> </b>"

---

{{% notice note %}}
Task 01은 crm CLI를 사용하여 마스터 노드에서 실행중인 SAP HANA에서 보조(대기) 노드로 수동 마이그레이션을 수행하는 방법을 보여주는 것입니다. 이 실습을 시작하기 전에 클러스터의 모든 서비스가 오류 없이 정상적으로 실행 중인 상태를 먼저 확인해야합니다.
{{% /notice %}}

### Migrating a HANA primary
테스트 시나리오
![image02](../images/02.png)

1. Lab 02. Task 03. HAWK(High Availability Web Konsole)을 수행하여 Web을 통해 Cluster의 상태를 확인합니다.

2. Lab 03. Task 01. Validation of Cluster를 수행하여 CLI를 통해 Cluster의 상태를 확인합니다.

3. Overlay IP 리소스를 마이그레이션 하기 위해 Management Console에 로그인 한 뒤 [EC2 Instance Console](https://console.aws.amazon.com/ec2/v2/home?region=us-east-1#Instances:sort=instanceId)에 접속 합니다.

4. **HANA-HDB-Primary** 인스턴스를 선택하고, **Connect** 버튼을 누릅니다.
![image01-01](images/01-01-new.png)

5. **Session Manager** 를 선택하고, **Connect** 버튼을 누릅니다. Session Manager를 통해 **prihana** 인스턴스에 접속합니다.
![image01-02](images/01-02-new.png)

6. Node1(prihana)에서아래 명령을 실행하여 Overray IP 리소스인 res_AWS_IP를 Node2(sechana)로 마이그레이션합니다.
     ```shell
    sudo su -
    crm resource migrate res_AWS_IP force
     ```

    {{% notice note %}}
    "migrate"명령을 사용했기 때문에 클러스터는 현재 상태의 Primary Node(prihana)의 RA를 중지하고 Secondary Node를 "Master"로 승격합니다.
    시스템 복제가 INSYNC (SFAIL) 상태인 경우 Primary룰 마이그레이션하지 말아야합니다. Secondary Node가 새 Primary가 될 때까지 기다립니다.
    {{% /notice %}}

7. **sechana** 에 들어가서 Cluster 및 HSR 상태를 확인합니다.

8. [EC2 Instance Console](https://console.aws.amazon.com/ec2/v2/home?region=us-east-1#Instances:sort=instanceId)에 접속 합니다.

9. **HANA-HDB-Secondary** 인스턴스를 선택하고, **Connect** 버튼을 누릅니다.
    ![image01-08](images/01-08-new.png)

10. **Session Manager** 를 선택하고, **Connect** 버튼을 누릅니다. Session Manager를 통해 **sechana** 인스턴스에 접속합니다.
    ![image01-02](images/01-02-new.png)

11. Cluster의 상태를 체크 합니다.
    * **crm_mon** 은 Cluster의 현재 상태를 제공하는 명령어 입니다.(root 유저사용)
    * 아래 명령어를 수행하여 **sechana** 가 **Master** 상태인지 확인 합니다.
    ```shell
    sudo su -
    crm_mon -rfn1
    ```
    ![image01-09](images/01-09.png)

12. SAP HANA System Replication (HSR) 상태 체크를 합니다.
    * **SAPHanaSR-showAttr** 사용하여 **prihana** node가 **SOK** 확인 합니다. (root 유저사용)
    ```shell
    sudo su -
    SAPHanaSR-showAttr
    ```
    ![image01-10](images/01-10.png)

13. Bastion Host에 접속해서 HAWK 웹의 Dashboard를 확인합니다. (Lab02 참고)
    * Overlay IP Resource가 sechana로 넘어 간것을 확인하실 수 있습니다.
    ![image01-12](images/01-12.png)

14. Secondary Node (sechana)에서 클러스터가 Primary Node (prihana)에서시작될 수 있도록 리소스 마이그레이션을 해제합니다.
    ```shell
    sudo su -
    crm resource unmigrate res_AWS_IP
    ```

---
<p align="center">
© 2019 Amazon Web Services, Inc. 또는 자회사, All rights reserved.
</p>
