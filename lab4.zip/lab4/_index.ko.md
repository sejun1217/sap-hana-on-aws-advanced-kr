---

title: Lab 04. Admin Cluster
weight: 50
pre: "<b>5. </b>"

---

#### Lab 설명

{{% notice note %}}
***HA Cluster의 운영 중 필요한 여러 HA Cluster Command들에 대해 알아보도록합니다.***
{{% /notice %}}

---

#### Lab Architecture

이번 실습에서는 Cluster를 운영하면서 필요한 여러 상황에 필요한 HA Cluster 명령어들을 실행해 볼 것입니다.
* 클러스터 마이그레이션 명령을 사용하여 HANA 기본 마이그레이션을 수행 (Primary-->Secondary)
* 클러스터 노드를 대기 상태로 변경하여 노드를 오프라인으로 전환 (Secondary-->Primary)
* SAP HANA System Replication 수행
* Cluster Resource Agents 테스트
* SUSE Cluster Software Upgrading 개념과 절차

1. Test Architecture
![image01](images/01.png)

2. Secondary(on sechana) to take over as Primary
![image02](images/02.png)

2. Secondary(on prihana) to take back as Primary
![image03](images/03.png)


---

<p align="center">
© 2019 Amazon Web Services, Inc. 또는 자회사, All rights reserved.
</p>
